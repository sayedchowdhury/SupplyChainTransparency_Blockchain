from web3 import Web3, Account
import json
from web3.middleware import geth_poa_middleware
from web3.exceptions import ExtraDataLengthError
from dotenv import load_dotenv
import os
from eth_utils import to_checksum_address

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Load ABI from the JSON file
with open(os.path.join(BASE_DIR, "contracts", "supply_chain_abi.json")) as f:
    supply_chain_abi = json.load(f)
if supply_chain_abi is None:
    print("Error loading Supply Chain ABI.")
    exit(1)

load_dotenv()
CELO_PRIVATE_KEY = os.getenv('CELO_PRIVATE_KEY')
if CELO_PRIVATE_KEY is None:
    print("Please set the CELO_PRIVATE_KEY in the .env file")
    exit(1)

provider_url = "https://alfajores-forno.celo-testnet.org"
web3 = Web3(Web3.HTTPProvider(provider_url))
if not web3.is_connected():
    print("Failed to connect to the Celo network")
    exit(1)

deployer = web3.eth.account.from_key(CELO_PRIVATE_KEY)
account = deployer
print(f"Connected to Celo network. Address: {deployer.address}")
web3.middleware_onion.inject(geth_poa_middleware, layer=0)

#place  Supply Chain Contract 
supply_chain_address = "0x650Fe75F1EaC682e3365F8C8348B38eF1713FD0E"  # Replace with your deployed contract address
supply_chain_address = to_checksum_address(supply_chain_address)
supply_chain_contract = web3.eth.contract(address=supply_chain_address, abi=supply_chain_abi)

# Functions for supply chain contract
def add_product(product_code, name, price, location_id, initial_quantity):
    try:
        transaction = supply_chain_contract.functions.addProduct(
            int(product_code),
            name,
            price,
            location_id,
            initial_quantity
        ).build_transaction({
            'chainId': 44787,  # Alfajores testnet chainId
            'gas': 3000000,    # Adjust gas value as needed
            'gasPrice': web3.to_wei('10', 'gwei'),  # Adjust gasPrice as needed
            "nonce": web3.eth.get_transaction_count(account.address),
        })
        signed_transaction = web3.eth.account.sign_transaction(transaction, CELO_PRIVATE_KEY)
        tx_hash = web3.eth.send_raw_transaction(signed_transaction.rawTransaction)
        tx_receipt = web3.eth.wait_for_transaction_receipt(tx_hash)
        if tx_receipt['status'] == 1:
            print("Product added successfully.")
            return tx_receipt
        else:
            print("Failed to add product.")
    except Exception as e:
        print(f"Error adding product: {e}")
        return e

def update_inventory(product_code, new_quantity):
    try:
        transaction = supply_chain_contract.functions.updateInventory(
            product_code,
            new_quantity
        ).build_transaction({
            'chainId': 44787,
            'gas': 3000000,
            'gasPrice': web3.to_wei('10', 'gwei'),
            "nonce": web3.eth.get_transaction_count(account.address),
        })
        signed_transaction = web3.eth.account.sign_transaction(transaction, CELO_PRIVATE_KEY)
        tx_hash = web3.eth.send_raw_transaction(signed_transaction.rawTransaction)
        tx_receipt = web3.eth.wait_for_transaction_receipt(tx_hash)
        if tx_receipt['status'] == 1:
            print("Inventory updated successfully.")
            return tx_receipt
        else:
            print("Failed to update inventory.")
    except Exception as e:
        print(f"Error updating inventory: {e}")
        return e

def get_product(product_code):
    try:
        return supply_chain_contract.functions.getProduct(product_code).call()
    except Exception as e:
        print(f"Error retrieving product: {e}")
        return None

def get_inventory(product_code):
    try:
        return supply_chain_contract.functions.getInventory(product_code).call()
    except Exception as e:
        print(f"Error retrieving inventory: {e}")
        return None

def get_all_products():
    try:
        product_count = supply_chain_contract.functions.productCount().call()
        products = []
        for i in range(product_count):
            product_code = supply_chain_contract.functions.productCodes(i).call()
            product = get_product(product_code)
            products.append(product)
        return products
    except Exception as e:
        print(f"Error retrieving all products: {e}")
        return None

# Helper functions for Django integration
def add_product_to_blockchain(product, quantity):
    return add_product(
        product.product_code,
        product.name,
        int(product.price),
        product.location.id,
        quantity
    )

def update_inventory_on_blockchain(product_code, new_quantity):
    return update_inventory(product_code, new_quantity)

def get_product_from_blockchain(product_code):
    return get_product(product_code)

def get_inventory_from_blockchain(product_code):
    return get_inventory(product_code)

def get_all_products_from_blockchain():
    return get_all_products()

if __name__ == "__main__":
    print("Connected to Celo network")
    print(f"Deployer address: {deployer.address}")
    print(f"Supply Chain Contract address: {supply_chain_contract.address}")
    # You can add test calls here if needed
