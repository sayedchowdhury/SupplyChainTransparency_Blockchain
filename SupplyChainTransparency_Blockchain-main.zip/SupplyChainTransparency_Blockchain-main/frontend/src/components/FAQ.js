import Navbar from "./Navbar";
import React from 'react';

const FAQ = () => {
  return (
    <>
      <Navbar />
      <section className="dark:bg-gray-100 dark:text-gray-800">
        <div className="container flex flex-col justify-center p-4 mx-auto md:p-8">
          <p className="p-2 text-sm font-medium tracking-wider text-center uppercase">How it works</p>
          <h2 className="mb-12 text-4xl font-bold leading-none text-center sm:text-5xl">Frequently Asked Questions</h2>
          <div className="grid gap-10 md:gap-8 sm:p-3 md:grid-cols-2 lg:px-12 xl:px-32">
            <div>
              <h3 className="font-semibold">What supply chain services do we offer?</h3>
              <p className="mt-1 dark:text-gray-600">We specialize in providing comprehensive supply chain solutions for small businesses, including inventory management, order fulfillment, and logistics support to streamline your distribution process.</p>
            </div>
            <div>
              <h3 className="font-semibold">How can I track my order?</h3>
              <p className="mt-1 dark:text-gray-600">After placing an order, you can monitor its progress through our online tracking system. You'll receive real-time updates as your order moves from our warehouse to your business location.</p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default FAQ;
