import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';

function RegisterPage() {
  const [formData, setFormData] = useState({
    username: '',
    first_name: '',
    last_name: '',
    email: '',
    password1: '',
    password2: '',
    phone: ''
  });
  const [locations, setLocations] = useState([]);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevFormData => ({
      ...prevFormData,
      [name]: value
    }));
  };
  useEffect(() => {
     fetchLocations();
    }, []);

  const fetchLocations = async () => {
    try {
        const response = await axios.get('http://localhost:8000/delivery/locations/');
        setLocations(response.data);
      } catch (error) {
        console.error('Error fetching locations:', error);
      }
    };


  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8000/api/register/', formData);
      navigate('/');
    } catch (error) {
      setErrors(error.response.data);
    }
  };

  return (
    <div className="flex items-center justify-center h-screen bg-gray-100">
      <div className="w-full max-w-md">

        <form className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4" onSubmit={handleSubmit}>
        <div className="text-xl font-bold text-blue-600 mb-4">
        Welcome! Fill in the form below to create your account
        </div>
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="username">
              Username
            </label>
            <input
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              id="username"
              type="text"
              name="username"
              value={formData.username}
              onChange={handleChange}
              required
            />
          </div>
{errors.username && <div className="text-center text-red-500">{errors.username}</div>}
          {/* First Name */}
<div className="mb-4">
  <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="first_name">
    First Name
  </label>
  <input
    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
    id="first_name"
    type="text"
    name="first_name"
    value={formData.first_name}
    onChange={handleChange}
    required
  />
</div>

{/* Last Name */}
<div className="mb-4">
  <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="last_name">
    Last Name
  </label>
  <input
    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
    id="last_name"
    type="text"
    name="last_name"
    value={formData.last_name}
    onChange={handleChange}
    required
  />
</div>

{/* Email */}
<div className="mb-4">
  <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">
    Email
  </label>
  <input
    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
    id="email"
    type="email"
    name="email"
    value={formData.email}
    onChange={handleChange}
    required
  />
</div>
{errors.email && <div className="text-center text-red-500">{errors.email}</div>}
{/* Password */}
<div className="mb-4">
  <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="password1">
    Password
  </label>
  <input
    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline"
    id="password1"
    type="password"
    name="password1"
    value={formData.password1}
    onChange={handleChange}
    required
  />
</div>
{errors.password1 && <div className="text-center text-red-500">{errors.password1}</div>}
{/* Confirm Password */}
<div className="mb-4">
  <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="password2">
    Confirm Password
  </label>
  <input
    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline"
    id="password2"
    type="password"
    name="password2"
    value={formData.password2}
    onChange={handleChange}
    required
  />
</div>
{errors.password2 && <div className="text-center text-red-500">{errors.password2}</div>}
{/* Phone */}

    <div className="mb-4">
      <label className="block text-gray-700 font-bold mb-2" htmlFor="location">
        Location
      </label>
      <div className="relative">
        <select
          className="appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          id="location"
          name="location"
          value={formData.location}
          onChange={handleChange}
          required
        >
          <option value="">Select a location</option>
          {locations.map((location) => (
            <option key={location.id} value={location.id}>
              {location.name}
            </option>
          ))}
        </select>
        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
          <svg
            className="fill-current h-4 w-4"
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 20 20"
          >
            <path d="M10 12l-6-6 1.41-1.41L10 9.17l4.59-4.58L16 6l-6 6z" />
          </svg>
        </div>
      </div>
    </div>
    {errors.location && <div className="text-center text-red-500">{errors.location}</div>}


<div className="mb-4">
  <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="phone">
    Phone
  </label>
  <input
    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
    id="phone"
    type="text"
    name="phone"
    value={formData.phone}
    onChange={handleChange}
    required
  />
</div>
{errors.phone && <div className="text-center text-red-500">{errors.phone}</div>}
          <div className="flex items-center justify-between">
            <button
              className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
              type="submit"
            >
              Register
            </button>
            <Link to="/" className="inline-block align-baseline font-bold text-sm text-blue-500 hover:text-blue-800">
              Already have an account?
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
}

export default RegisterPage;
