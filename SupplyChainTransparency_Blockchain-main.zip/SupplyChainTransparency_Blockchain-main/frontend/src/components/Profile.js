import React, { useState } from 'react';
import Navbar from './Navbar';
import { useUser } from './UserContext';

const Profile = () => {
  const { user, updateUser } = useUser();
  const [editMode, setEditMode] = useState(false);

  console.log(user);
  const handleInputChange = (event) => {
    if (user) {
      updateUser({
        ...user,
        [event.target.name]: event.target.value,
      });
    }
  };

  const handleEdit = () => {
    setEditMode(true);
  };

    // This function will save the updated user data
  const handleSave = async () => {
    const response = await fetch('http://localhost:8000/api/user-data/', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${localStorage.getItem('accessToken')}`,
      },
      body: JSON.stringify(user)
    });

    if (response.ok) {
      // Fetch the updated user data
      const updatedResponse = await fetch('http://localhost:8000/api/user-data/', {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('accessToken')}`,
        }
      });
      const updatedUser = await updatedResponse.json();
      updateUser(updatedUser);
      setEditMode(false);
    } else {
      console.error('Failed to update user data');
    }
  };

  if (!user) {
    return <div>Loading...</div>;
  }

  return (
    <>
      <Navbar />
      <div className="bg-gray-100 min-h-screen">
        <div className="container mx-auto py-12">
          <h1 className="text-5xl font-bold text-gray-800 mb-6 text-center">Profile Details</h1>
          <div className="bg-white shadow-md rounded-lg p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Username */}
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2">Username</label>
                {editMode ? (
                  <input type="text" name="username" value={user.username} onChange={handleInputChange} className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" />
                ) : (
                  <p className="text-gray-600">{user.username}</p>
                )}
              </div>
              {/* First Name */}
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2">First Name</label>
                {editMode ? (
                  <input type="text" name="firstname" value={user.firstname} onChange={handleInputChange} className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" />
                ) : (
                  <p className="text-gray-600">{user.firstname}</p>
                )}
              </div>
              {/* Last Name */}
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2">Last Name</label>
                {editMode ? (
                  <input type="text" name="lastname" value={user.lastname} onChange={handleInputChange} className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" />
                ) : (
                  <p className="text-gray-600">{user.lastname}</p>
                )}
              </div>
              {/* Email */}
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2">Email</label>
                {editMode ? (
                  <input type="email" name="email" value={user.email} onChange={handleInputChange} className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" />
                ) : (
                  <p className="text-gray-600">{user.email}</p>
                )}
              </div>
              {/* Phone */}
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2">Phone</label>
                {editMode ? (
                  <input type="number" name="phone" value={user.phone} onChange={handleInputChange} className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" />
                ) : (
                  <p className="text-gray-600">+254 {user.phone}</p>
                )}
              </div>
            </div>
            {editMode ? (
              <button onClick={handleSave} className="bg-indigo-600 hover:bg-indigo-800 text-white font-bold py-2 px-4 rounded transition duration-300 ease-in-out">Save</button>
            ) : (
              <button onClick={handleEdit} className="bg-indigo-600 hover:bg-indigo-800 text-white font-bold py-2 px-4 rounded transition duration-300 ease-in-out">Edit</button>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default Profile;
