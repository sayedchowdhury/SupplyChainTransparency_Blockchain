import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import { useUser } from './UserContext';

function LoginPage() {
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });
  const [errors, setErrors] = useState({});
  const [error, setError] = useState('');
  const [loginType, setLoginType] = useState('customer'); // Added loginType state
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevFormData => ({
      ...prevFormData,
      [name]: value
    }));
  };

  const { updateUser } = useUser();

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const loginEndpoint = loginType === 'customer' ? 'http://localhost:8000/api/token/' : 'http://localhost:8000/api/staff/login/';
      const response = await axios.post(loginEndpoint, {
        username: formData.username,
        password: formData.password,
      });

      const { access, refresh } = response.data;
      localStorage.setItem('accessToken', access);
      if (refresh) {
        localStorage.setItem('refreshToken', refresh);
      }

      const userInfoResponse = await axios.get('http://localhost:8000/api/user-data/', {
        headers: {
          Authorization: `Bearer ${access}`,
        },
      });

      updateUser(userInfoResponse.data);
      navigate('/home');
    } catch (error) {
      if (error.response) {
        setError('Invalid username or password.');
      } else {
        setError('An error occurred. Please try again later.');
      }
    }
  };

  const handleLoginTypeChange = (type) => {
    setLoginType(type);
    setFormData({ username: '', password: '' }); // Reset form data when switching login type
    setError(''); // Clear any previous error
  };

  return (
    <section className="bg-gray-50 min-h-screen flex items-center justify-center">
      <div className="w-full lg:w-4/12 px-4 mx-auto pt-6">
        <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-gray-200 border-0">
          <div className="rounded-t mb-0 px-6 py-6">
            <div className="text-center mb-3">
              <h6 className="text-gray-500 text-sm font-bold">Sign in as a</h6>
            </div>
        <div className="btn-wrapper text-center">
          {/* Toggle button appearance based on active state */}
          <button
            className={`px-4 py-2 rounded outline-none focus:outline-none mr-2 mb-1 uppercase shadow hover:shadow-md inline-flex items-center font-bold text-xs ease-linear transition-all duration-150 ${
              loginType === 'customer' ? 'border-2 border-blue-500 bg-blue-500 text-white' : 'border-2 border-gray-300 bg-white text-gray-700'
            }`}
            onClick={() => handleLoginTypeChange('customer')}
          >
            Customer
          </button>
          <button
            className={`px-4 py-2 rounded outline-none focus:outline-none mr-1 mb-1 uppercase shadow hover:shadow-md inline-flex items-center font-bold text-xs ease-linear transition-all duration-150 ${
              loginType === 'staff' ? 'border-2 border-blue-500 bg-blue-500 text-white' : 'border-2 border-gray-300 bg-white text-gray-700'
            }`}
            onClick={() => handleLoginTypeChange('staff')}
          >
            Staff
          </button>
        </div>
            <hr className="mt-6 border-b-1 border-blueGray-300" />
          </div>
          <div className="flex-auto px-4 lg:px-10 py-10 pt-0">

            {error && <p className="text-red-500 mb-4 text-center">{error}</p>}
            <form onSubmit={handleSubmit}>
              <div className="relative w-full mb-3">
                <label className="block uppercase text-blue-600 text-xs font-bold mb-2" htmlFor="username">
                  Username
                </label>
                <input
                  type="text"
                  className="border-0 px-3 py-3 placeholder-blue-300 text-blue-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  id="username"
                  name="username"
                  placeholder="Username"
                  value={formData.username}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="relative w-full mb-3">
                <label className="block uppercase text-blue-600 text-xs font-bold mb-2" htmlFor="password">
                  Password
                </label>
                <input
                  type="password"
                  className="border-0 px-3 py-3 placeholder-blue-300 text-blue-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  id="password"
                  name="password"
                  placeholder="Password"
                  value={formData.password}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className = "text-center mt-4 text-blue-600">
                <Link to="/register">New Here? Click here to create an account </Link>
                </div>
              <div className="text-center mt-6">
                <button
                  className="bg-blue-800 text-white active:bg-blue-600 text-sm font-bold uppercase px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 w-full ease-linear transition-all duration-150"
                  type="submit"
                >
                  Sign In
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LoginPage;