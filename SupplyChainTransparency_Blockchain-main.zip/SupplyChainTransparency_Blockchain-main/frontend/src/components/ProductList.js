import Navbar from "./Navbar";
import { SearchIcon } from '@heroicons/react/outline'; // Import SearchIcon from Heroicons
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Loader from './Loader';

const ProductList = () => {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const accessToken = localStorage.getItem('accessToken');
        const response = await axios.get('http://localhost:8000/store/products/products-with-location', {
          headers: {
            'Authorization': `Bearer ${accessToken}`
          }
        });
        setProducts(response.data);
        console.log(products);
        setFilteredProducts(response.data);
      } catch (error) {
        console.error('Error fetching products:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchProducts();
  }, []);

  // Handle search input change
  const handleSearchInputChange = (e) => {
    setSearchQuery(e.target.value);
    filterProducts(e.target.value);
  };

  // Filter products based on search query
  const filterProducts = (query) => {
    const filtered = products.filter(product =>
      (product.product_code.toString().toLowerCase().includes(query.toLowerCase())) ||
      product.name.toLowerCase().includes(query.toLowerCase())
    );
    setFilteredProducts(filtered);
  };

  return (
    <div>
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <div className="bg-gray-100 shadow-md rounded-lg p-6">
          <div className="static">
            <input
              type="text"
              placeholder="Search products..."
              value={searchQuery}
              onChange={handleSearchInputChange}
              className="w-full px-4 py-2 pr-10 rounded-md border border-gray-300 bg-gray-200 focus:outline-none focus:border-blue-500"
            />

          </div>
          <p className="text-gray-800 text-xl mt-4 mb-4">These are the products we offer. To make an order, please navigate to the create order page in the orders link in navigation.</p>
          {isLoading ? (
            <div className="flex justify-center items-center mt-4">
              <Loader />
            </div>
          ) : (
                   <ul className="list-none mt-4">
                  <li className="border-b border-gray-200 py-2">
                    <div className="grid grid-cols-4 gap-4 items-center font-bold">
                      <span className="text-gray-800 text-xl">Product Code</span>
                      <span className="text-gray-800 text-xl">Product Name</span>
                      <span className="text-gray-800 text-xl">Location</span>
                      <span className="text-gray-800 text-xl justify-self-end">Price</span>
                    </div>
                  </li>
                  {filteredProducts.map((product) => (
                    <li key={product.product_code} className="border-b border-gray-200 py-2">
                      <div className="grid grid-cols-4 gap-4 items-center">
                        <span className="text-gray-700 text-lg">{product.product_code}</span>
                        <span className="text-gray-700 text-lg">{product.name}</span>
                        <span className="text-gray-700 text-lg">{product.location_name}</span>
                        <span className="text-gray-500 text-lg justify-self-end">{product.price}</span>
                      </div>
                    </li>
                  ))}
                </ul>

          )}
        </div>
      </div>
    </div>
  );
};

export default ProductList;
