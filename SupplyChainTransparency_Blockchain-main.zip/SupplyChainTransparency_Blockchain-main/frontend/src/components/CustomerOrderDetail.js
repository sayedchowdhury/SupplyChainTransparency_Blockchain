import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Loader from './Loader';
import Navbar from './Navbar';
import { FaUser, FaCalendarAlt, FaMoneyBillWave } from 'react-icons/fa'; // Import additional icon for product

const CustomerOrderDetails = () => {
  const [orderDetails, setOrderDetails] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchOrderDetails = async () => {
      try {
        const accessToken = localStorage.getItem('accessToken');
        const response = await axios.get('http://localhost:8000/order_flow/orders/customer-order-details/', {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        });
        // Format the response data to include necessary details
        const formattedData = response.data.map(order => ({
          ...order.order,
          order_items: order.order_items,
          total_cost: parseFloat(order.total_cost).toFixed(2) // Format the total cost
        }));
        setOrderDetails(formattedData);
      } catch (error) {
        console.error('Error fetching order details:', error);
        setError('Failed to fetch order details.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchOrderDetails();
  }, []);

  if (isLoading) {
    return <Loader />;
  }

  if (error) {
    return <div className="text-red-500 text-center font-bold mt-5">{error}</div>;
  }

  return (
    <div className="bg-gray-100 min-h-screen">
      <Navbar />
      <div className="container mx-auto p-4">
        <div className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
          <h1 className="text-2xl font-bold mb-4 text-gray-800">Order Details</h1>
          {orderDetails.length === 0 ? (
            <div className="text-gray-700 text-center font-bold mt-5">No orders found.</div>
          ) : (
            <table className="min-w-full bg-white">
              <thead>
                <tr>
                  <th className=" pr-8 border-b-2 border-gray-300">Order ID</th>
                  <th className=" pr-8 border-b-2 border-gray-300">Customer ID</th>
                  <th className="pr-8 border-b-2 border-gray-300">Order Date</th>
                  <th className=" pr-8  border-b-2 border-gray-300">Product ID</th>
                  <th className="pr-8 border-b-2 border-gray-300">Quantity</th>
                  <th className="pr-8 border-b-2 border-gray-300">Delivery Fee</th>
                  <th className="pr-8 border-b-2 border-gray-300 ">Total Cost</th>
                  <th className="pr-8 border-b-2 border-gray-300">Order Status</th>
                </tr>
              </thead>
              <tbody>
                  {orderDetails.map(order => (
                    order.order_items.map(item => (
                      <tr  key={`${order.order_id}-${item.id}`}>
                        <td className="pl-12 py-2 px-4  border-b border-gray-300">{order.order_id}</td>
                        <td className="pl-12 py-2 px-4 border-b border-gray-300">{order.customer}</td>
                        <td className="pl-12 py-2 px-4 border-b border-gray-300">{order.order_date}</td>
                        <td className="pl-12 py-2 px-4 border-b border-gray-300">{item.product}</td>
                        <td className="pl-12 py-2 px-4 border-b border-gray-300">{item.quantity}</td>
                        <td className="pl-12 py-2 px-4 border-b border-gray-300">{item.delivery_fee}</td>
                        <td className="pl-12 py-2 px-4 border-b border-gray-300">${parseFloat(order.total_cost) + parseFloat(item.delivery_fee)}</td>
                        <td className="pl-12  py-2 px-4 border-b text-gray-400 border-gray-300 font-semibold">{order.status}</td>
                      </tr>
                    ))
                  ))}
                </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};

export default CustomerOrderDetails;
