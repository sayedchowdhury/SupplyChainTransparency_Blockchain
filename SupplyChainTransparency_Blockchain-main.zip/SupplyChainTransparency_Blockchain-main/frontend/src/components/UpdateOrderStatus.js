import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from './Navbar';
import { FaBoxOpen, FaCalendarAlt, FaUser, FaList, FaSyncAlt } from 'react-icons/fa';

const UpdateOrderStatus = () => {
    const [orders, setOrders] = useState([]);
    const [selectedOrder, setSelectedOrder] = useState(null);
    const [status, setStatus] = useState('');
    const [error, setError] = useState('');

    useEffect(() => {
        // Fetch all orders
        const fetchOrders = async () => {
            try {
                const response = await axios.get('http://localhost:8000/order_flow/orders/order-details/');
                setOrders(response.data);
            } catch (error) {
                setError('Failed to fetch orders.');
            }
        };
        fetchOrders();
    }, []);

    const handleOrderSelection = (order) => {
        setSelectedOrder(order);
        setStatus(order.order.status);
    };

    const handleStatusChange = async () => {
        try {
            await axios.patch(`http://localhost:8000/order_flow/orders/${selectedOrder.order.order_id}/update-status/`, { status });
            setSelectedOrder({ ...selectedOrder, order: { ...selectedOrder.order, status } });
        } catch (error) {
            setError('Failed to update order status.');
        }
    };

    return (
    <>
    <Navbar/>
        <div className="container mx-auto p-4">
            <div className="bg-gray-100 shadow-md rounded p-4">
                <h2 className="text-2xl font-bold mb-4 flex items-center"><FaSyncAlt className="mr-2" />Update Order Status</h2>
                {error && <div className="text-red-500 mb-4">{error}</div>}
                <div className="mb-4">
                    <label className="block text-gray-700 text-sm font-bold mb-2 flex items-center"><FaList className="mr-2" />Select Customer Order you want to update:</label>
                    <select
                        onChange={(e) => handleOrderSelection(JSON.parse(e.target.value))}
                        className="block appearance-none w-full bg-blue-50 border border-blue-300 text-gray-700 py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-blue-100 focus:border-blue-500"
                    >
                        <option value="">Select an order</option>
                        {orders.map((order) => (
                            <option key={order.order.order_id} value={JSON.stringify(order)}>
                                {order.order.order_id} - {order.customer_name}
                            </option>
                        ))}
                    </select>
                </div>

                {selectedOrder && (
                    <>
                        <div className="mb-4 flex items-center">
                            <FaBoxOpen className="text-gray-500 mr-2" />
                            <div className="flex-1 border px-4 py-2 bg-gray-50">{selectedOrder.order.order_id}</div>
                        </div>
                        <div className="mb-4 flex items-center">
                            <FaUser className="text-gray-500 mr-2" />
                            <div className="flex-1 border px-4 py-2 bg-gray-50">{selectedOrder.customer_name}</div>
                        </div>
                        <div className="mb-4 flex items-center">
                            <FaCalendarAlt className="text-gray-500 mr-2" />
                            <div className="flex-1 border px-4 py-2 bg-gray-50">{selectedOrder.order.order_date}</div>
                        </div>
                        <div className="mb-4">
                            <label className="block text-gray-700 text-sm font-bold mb-2">Order Items:</label>
                            <ul className="border px-4 py-2 bg-gray-50">
                                {selectedOrder.products.map((product, index) => (
                                  <li key={index}>
                                    {product.name} - ${product.price} each
                                  </li>
                                ))}
                                {selectedOrder.order_items.map((item, index) => (
                                    <li key={index}>
                                        {item.product.name} - {item.quantity} pcs
                                    </li>

                                ))}
                            </ul>
                        </div>
                        <div className="mb-4 flex items-center">
                            <FaSyncAlt className="text-gray-500 mr-2" />
                            <div className="flex-1 border px-4 py-2 bg-gray-50">Currently {selectedOrder.order.status}</div>
                        </div>
                        <div className="mb-4">
                            <label className="block text-gray-700 text-sm font-bold mb-2 flex items-center"><FaSyncAlt className="mr-2" />Update Status:</label>
                            <select
                                value={status}
                                onChange={(e) => setStatus(e.target.value)}
                                className="block appearance-none w-full bg-blue-50 border border-blue-300 text-gray-700 py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-blue-100 focus:border-blue-500"
                            >
                                <option value="pending">Pending</option>
                                <option value="processing">Processing</option>
                                <option value="shipped">Shipped</option>
                                <option value="delivered">Delivered</option>
                            </select>
                        </div>
                        <button
                            onClick={handleStatusChange}
                            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline flex items-center"
                        >
                            <FaSyncAlt className="mr-2" />Update Status
                        </button>
                    </>
                )}
            </div>
        </div>
        </>
    );
};

export default UpdateOrderStatus;
