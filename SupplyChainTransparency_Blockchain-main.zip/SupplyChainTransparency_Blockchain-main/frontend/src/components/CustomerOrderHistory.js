import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import Loader from './Loader';
import Navbar from "./Navbar"
import { UserContext } from './UserContext'; // Assuming you have a UserContext

const CustomerOrderHistory = () => {
  const [orderHistory, setOrderHistory] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchOrderHistory = async () => {
      try {
        const accessToken = localStorage.getItem('accessToken');
        const response = await axios.get('http://localhost:8000/order_flow/orders/order-history', {
          headers: {
            Authorization: `Bearer ${accessToken}`, // Use the access token from local storage
          },
        });
        setOrderHistory(response.data);
      } catch (error) {
        console.error('Error fetching order history:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchOrderHistory();
  }, []);

  if (isLoading) {
    return <Loader />;
  }

  return (
  <div>
  <Navbar/>
    <div className="container mx-auto p-4">
      <div className="bg-white shadow-md rounded my-6">
        <div className="p-4">
          <h3 className="text-lg font-semibold">Order History</h3>
          <ul className="list-none p-4">
            {orderHistory.map((order) => (
              <li key={order.order_Id} className="border-b border-gray-200 py-2">
                <div className="flex justify-between items-center">
                  <span className="text-gray-700">{`Order ID: ${order.order_id}`}</span>
                  <span className="text-gray-500">{`Date: ${new Date(order.order_date).toLocaleDateString()}`}</span>
                    <span className="text-gray-700">{`Status: ${order.status}`}</span>
                    <span className="text-gray-500">{`Customer: ${order.customer}`}</span>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
    </div>
  );
};

export default CustomerOrderHistory;
