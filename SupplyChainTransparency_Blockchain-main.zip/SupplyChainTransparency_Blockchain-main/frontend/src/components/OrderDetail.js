import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Loader from './Loader';
import Table from './Table';
import Navbar from './Navbar';
import { FaSearch } from 'react-icons/fa'; // Import search icon

const OrderDetails = () => {
  const [orderDetails, setOrderDetails] = useState([]);
  const [filteredOrders, setFilteredOrders] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchOrderDetails = async () => {
      try {
        const accessToken = localStorage.getItem('accessToken');
        const response = await axios.get('http://localhost:8000/order_flow/orders/order-details', {
          headers: {
            Authorization: `Bearer ${accessToken}`, // Include the access token in the Authorization header
          },
        });
        setOrderDetails(response.data);
        setFilteredOrders(response.data);
      } catch (error) {
        console.error('Error fetching order details:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchOrderDetails();
  }, []);

  useEffect(() => {
    const results = orderDetails.filter(order =>
      order.order.order_id.toString().includes(searchTerm)
    );
    setFilteredOrders(results);
  }, [searchTerm, orderDetails]);

  if (isLoading) {
    return <Loader />;
  }

  return (
    <>
      <Navbar />
      <div className="container mx-auto p-4">
        <div className="flex justify-between items-center mb-4">
          <h1 className="text-2xl font-bold text-gray-800">Order Details</h1>
          <div className="flex items-center border border-gray-300 rounded-md p-2">
            <FaSearch className="text-gray-500 mr-2" />
            <input
              type="text"
              placeholder="Search by Order ID"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="outline-none"
            />
          </div>
        </div>
        <div className="flex flex-wrap justify-center gap-4">
          {filteredOrders.length === 0 ? (
            <div className="text-gray-700 text-center font-bold mt-5">No orders found.</div>
          ) : (
            filteredOrders.map(order => (
              <div key={order.order.id} className="bg-white p-4 rounded-lg shadow-lg max-w-3xl w-full">
                <div className="mb-4">
                  <h2 className="text-blue-800 text-xl font-bold">Order Summary</h2>
                  <Table
                    data={[{
                      order_id: order.order.order_id,
                      order_date: order.order.order_date,
                      total_cost: `$${order.total_cost.toFixed(2)}`,
                    }]}
                    columns={[
                      { key: 'order_id', label: 'Order ID' },
                      { key: 'order_date', label: 'Date' },
                      { key: 'total_cost', label: 'Total Cost' },
                    ]}
                  />
                </div>
                <div className="mb-4">
                  <h3 className="text-blue-800 text-lg font-bold">Customer Details</h3>
                  <Table
                    data={[{
                      customer_name: order.customer_name,
                      customer_email: order.customer_email,
                      customer_phone: order.customer_phone
                    }]}
                    columns={[
                      { key: 'customer_name', label: 'Name' },
                      { key: 'customer_email', label: 'Email' },
                      { key: 'customer_phone', label: 'Phone' },
                    ]}
                  />
                </div>
                <div className="mb-4">
                  <h3 className="text-blue-800 text-lg font-bold">Products</h3>
                  <Table
                    data={order.products.map(product => ({
                      name: product.name,
                      quantity: product.quantity,
                      price: `$${product.price.toFixed(2)}`
                    }))}
                    columns={[
                      { key: 'name', label: 'Product Name' },
                      { key: 'quantity', label: 'Quantity' },
                      { key: 'price', label: 'Price' },
                    ]}
                  />
                </div>
                {/*
                <div>
                  <h3 className="text-blue-800 text-lg font-bold">Items</h3>
                  <Table
                    data={order.order_items.map(item => ({
                      name: item.product.name,
                      quantity: item.quantity,
                      price: `$${(item.product.price * item.quantity).toFixed(2)}`
                    }))}
                    columns={[
                      { key: 'name', label: 'Product Name' },
                      { key: 'quantity', label: 'Quantity' },
                      { key: 'price', label: 'Total Price' },
                    ]}
                  />
                </div>*/}
              </div>
            ))
          )}
        </div>
      </div>
    </>
  );
};

export default OrderDetails;
