import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from "./Navbar";
import { useUser } from './UserContext';
import { FaPlus, FaMinus, FaTrash } from 'react-icons/fa'; // Import icons for a better visual cue

const CreateOrder = () => {
  const { user } = useUser();
  const [items, setItems] = useState([{ product_code: '', quantity: 1 }]);
  const [products, setProducts] = useState([]);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await axios.get('http://localhost:8000/store/products/');
      setProducts(response.data);
    } catch (error) {
      setError('Error fetching products');
    }
  };

  const handleItemChange = (index, field, value) => {
    const updatedItems = [...items];
    updatedItems[index][field] = value;
    setItems(updatedItems);
  };

  const handleQuantityChange = (index, change) => {
    const updatedItems = [...items];
    updatedItems[index].quantity = Math.max(updatedItems[index].quantity + change, 1);
    setItems(updatedItems);
  };

  const handleRemoveItem = (index) => {
    const updatedItems = [...items];
    updatedItems.splice(index, 1);
    setItems(updatedItems);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const accessToken = localStorage.getItem('accessToken');
      await axios.post('http://localhost:8000/order_flow/orders/create-order/', { items }, {
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });
      setSuccess('Order created successfully!');
      setItems([{ product_code: '', quantity: 1 }]);
    } catch (error) {
      setError('Failed to create order');
    }
  };

  return (
    <div>
      <Navbar />
      <div className="container mx-auto p-4">
        <div className="max-w-2xl mx-auto bg-white rounded shadow-md p-6">
          <h2 className="text-2xl font-semibold text-center mb-6">Create Order</h2>
          {error && <div className="p-3 mb-4 text-center text-red-600 bg-red-100 rounded">{error}</div>}
          {success && <div className="p-3 mb-4 text-center text-green-600 bg-green-100 rounded">{success}</div>}
          <form onSubmit={handleSubmit}>
            {items.map((item, index) => (
              <div key={index} className="flex items-center mb-4">
                <select
                  value={item.product_code}
                  onChange={(e) => handleItemChange(index, 'product_code', e.target.value)}
                  className="flex-grow p-2 bg-gray-200 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select Product</option>
                  {products.map(product => (
                    <option key={product.product_code} value={product.product_code}>{product.name}</option>
                  ))}
                </select>
                <div className="flex items-center ml-4">
                  <button
                    type="button"
                    onClick={() => handleQuantityChange(index, -1)}
                    className="p-2 text-gray-600 bg-gray-200 rounded hover:bg-gray-300 focus:outline-none"
                  >
                    <FaMinus />
                  </button>
                  <input
                    type="number"
                    value={item.quantity}
                    readOnly
                    className="w-16 p-2 mx-2 text-center bg-gray-200 border border-gray-300 rounded focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => handleQuantityChange(index, 1)}
                    className="p-2 text-gray-600 bg-gray-200 rounded hover:bg-gray-300 focus:outline-none"
                  >
                    <FaPlus />
                  </button>
                </div>
                {index > 0 && (
                  <button
                    type="button"
                    onClick={() => handleRemoveItem(index)}
                    className="ml-4 p-2 text-gray-600 bg-gray-200 rounded hover:bg-gray-300 focus:outline-none"
                  >
                    <FaTrash />
                  </button>
                )}
              </div>
            ))}
            <div className="flex justify-end pt-4">
              <button
                type="submit"
                className="px-6 py-2 text-white bg-blue-600 rounded hover:bg-blue-700 focus:ring-4 focus:ring-blue-300"
              >
                Submit Order
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CreateOrder;
