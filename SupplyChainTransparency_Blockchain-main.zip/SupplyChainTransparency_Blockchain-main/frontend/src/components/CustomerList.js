import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Loader from './Loader';
import Table from './Table';
import Navbar from './Navbar';

const CustomerList = () => {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchCustomers = async () => {
      setLoading(true);
      try {
        const response = await axios.get('http://localhost:8000/api/customers/');
        setCustomers(response.data);
      } catch (err) {
        setError('An error occurred while fetching customers.');
        console.error(err);
      }
      setLoading(false);
    };

    fetchCustomers();
  }, []);

  const columns = [
    { key: 'id', label: 'ID' },
    { key: 'name', label: 'Name' },
    { key: 'email', label: 'Email' },
    // Add more columns as needed
  ];

  if (loading) return <Loader />;
  if (error) return <p className="text-red-500 text-center">{error}</p>;

  return (
  <>
  <Navbar/>
    <div className="container mx-auto my-8">
      <Table data={customers} columns={columns} />
    </div>
    </>
  );
};

export default CustomerList;
