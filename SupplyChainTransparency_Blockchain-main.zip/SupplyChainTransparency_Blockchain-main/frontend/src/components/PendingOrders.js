import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from './Navbar';
import { AiOutlineExclamationCircle, AiOutlineClockCircle } from 'react-icons/ai';

const PendingOrders = () => {
    const [orders, setOrders] = useState([]);
    const [error, setError] = useState('');

    useEffect(() => {
        // Fetch pending orders
        const fetchPendingOrders = async () => {
            try {
                const response = await axios.get('http://localhost:8000/order_flow/orders/pending-orders/');
                setOrders(response.data);
            } catch (error) {
                setError('Failed to fetch pending orders.');
            }
        };
        fetchPendingOrders();
    }, []);

    return (<>
    <Navbar/>
        <div className="container mx-auto p-4">
            <div className="bg-yellow-100 shadow-md rounded p-6">
                <h2 className="text-2xl font-bold mb-4 flex items-center text-yellow-700">
                    <AiOutlineExclamationCircle className="mr-2" /> Pending Orders
                </h2>
                {error && <div className="text-red-500 mb-4">{error}</div>}
                <p className="mb-4 text-yellow-800">These orders need to be processed by the staff as soon as possible:If you can update their status based on progress
                 do so at update status link</p>
                {orders.length === 0 ? (
                    <div className="text-gray-700">No pending orders at the moment.</div>
                ) : (
                    <ul className="space-y-4">
                        {orders.map((order) => (
                            <li key={order.order_id} className="bg-white border border-yellow-300 rounded p-4 shadow flex justify-between items-center">
                                <div>
                                    <h3 className="text-lg font-semibold">Order ID: {order.order_id}</h3>
                                    <p className="text-gray-700">Customer: {order.customer_name}</p>
                                    <p className="text-gray-700">Order Date: {order.order_date}</p>
                                    <p className="text-gray-700">Total Cost: ${order.total_cost}</p>
                                    <p className="text-gray-700">Items:</p>
                                    <ul className="list-disc list-inside">
                                        {order.order_items.map((item, index) => (
                                            <li key={index}>
                                                {item.product.name} - {item.quantity} pcs
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                                <AiOutlineClockCircle className="text-yellow-500 text-2xl" />
                            </li>
                        ))}
                    </ul>
                )}
            </div>
        </div>
        </>
    );
};

export default PendingOrders;
