import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Table from './Table';
import Loader from './Loader';
import Navbar from "./Navbar"

const InventoryReport = () => {
  const [inventoryReport, setInventoryReport] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchInventoryReport = async () => {
      try {
        const accessToken = localStorage.getItem('accessToken');
        const response = await axios.get('http://localhost:8000/store/inventories/inventory-report/',{
        headers: {
          'Authorization': `Bearer ${accessToken}` // Include the access token in the Authorization header
        }
      });
        setInventoryReport(response.data);
      } catch (error) {
        console.error('Error fetching inventory report:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchInventoryReport();
  }, []);

  if (isLoading) {
    return <Loader />;
  }

  if (!inventoryReport) {
    return <div className="text-center mt-8">No data available</div>;
  }

  const { inventory_levels, order_history } = inventoryReport;

  const inventoryLevelsColumns = [
    { key: 'product__name', label: 'Product Name' },
    { key: 'product__product_code', label: 'Product Code' },
    { key: 'quantity', label: 'Quantity' },
  ];

  const orderHistoryColumns = [
    { key: 'status', label: 'Order Status' },
    { key: 'count', label: 'Count' },
  ];

  return (
  <div>
  <Navbar/>
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <h2 className="text-2xl font-bold mb-4">Inventory Report</h2>
      <div className="mb-8">
        <h3 className="text-xl font-bold mb-2">Inventory Levels</h3>
        <Table data={inventory_levels} columns={inventoryLevelsColumns} />
      </div>
      <div>
        <h3 className="text-xl font-bold mb-2">Order History</h3>
        <Table data={order_history} columns={orderHistoryColumns} />
      </div>
    </div>
    </div>
  );
};

export default InventoryReport;