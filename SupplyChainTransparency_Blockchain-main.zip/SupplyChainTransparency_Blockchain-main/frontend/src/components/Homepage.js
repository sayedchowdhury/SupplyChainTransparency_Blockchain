import React from 'react';
import { Link } from 'react-router-dom';
import Navbar from './Navbar';

const Homepage = () => {
  return (
    <div className="bg-gray-100 min-h-screen">
      <Navbar />
      <div className="container mx-auto py-12">
        <h1 className="text-5xl font-bold text-gray-800 mb-6 text-center">
          Welcome to Our  Supply Chain Management System
        </h1>

        <section className="mb-8 p-6 bg-gray-200 shadow-md rounded-lg">
          <h2 className="text-3xl font-semibold text-gray-700 mb-4">Overview</h2>
          <p className="text-gray-600 mb-4">
            Our Supply Chain Management System is designed to streamline and optimize your business operations,
            ensuring efficient inventory management, order fulfillment, and logistics coordination. Explore the
            features below to learn more.We try to implement transparency in our system by including Blockchain to track the inventory, based on orders customers make.
          </p>
        </section>

        <section className="mb-8 p-6 bg-gray-200  shadow-md rounded-lg">
          <h2 className="text-3xl font-semibold text-gray-700 mb-4">Key Features</h2>
          <ul className="list-disc list-inside space-y-2">
            <li>Improving Inventory Management</li>
            <li>Streamlining Order Fulfillment Procedures</li>
            <li>Optimizing Logistics Coordination</li>
          </ul>
        </section>

        <section className="mb-8 p-6 bg-gray-200  shadow-md rounded-lg">
          <h2 className="text-3xl font-semibold text-gray-700 mb-4">Navigation</h2>
          <p className="text-gray-600 mb-4">
            Use the links below to navigate to different sections of the system:
          </p>
          <div className="flex flex-wrap gap-4">
            <Link to="/product-list" className="text-indigo-600 hover:text-indigo-800 transition duration-300 ease-in-out">
              Product List
            </Link>
            <Link to="/create-order" className="text-indigo-600 hover:text-indigo-800 transition duration-300 ease-in-out">
              Create Order
            </Link>

          </div>
        </section>
      </div>
    </div>
  );
}

export default Homepage;
