import React from 'react';
import './LogoutModal.css';

const LogoutModal = ({ isOpen, onConfirm, onCancel }) => {
  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <p>Are you sure you want to log out?</p>
        <div className="modal-actions">
          <button onClick={onConfirm} className="modal-button confirm">Yes</button>
          <button onClick={onCancel} className="modal-button cancel">No</button>
        </div>
      </div>
    </div>
  );
};

export default LogoutModal;
