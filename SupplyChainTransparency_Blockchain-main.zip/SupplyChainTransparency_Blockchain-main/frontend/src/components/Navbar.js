import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import LogoutModal from './LogoutModal';
// import './NavBar.css';
import axios from 'axios';
import { useEffect } from 'react';
import { useUser } from './UserContext';
import { HomeIcon, ShoppingCartIcon, ClipboardListIcon, ArchiveIcon, UserGroupIcon, ChevronDownIcon, ChartBarIcon,UserIcon } from '@heroicons/react/outline'; // Import icons
import { MenuIcon, XIcon } from '@heroicons/react/outline';

import { Menu, Transition } from '@headlessui/react';
const Navbar = () => {
  const [isOpen, setIsOpen] = React.useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const navigate = useNavigate();
  const [showLogoutModal, setShowLogoutModal] = useState(false);
  const { user } = useUser();
  console.log(user);
  // Function to render dropdown menu items
  const DropdownLink = ({ to, children }) => (
    <Menu.Item>
      {({ active }) => (
        <Link
          to={to}
          className={`${active ? 'bg-gray-100 text-gray-900' : 'text-gray-700'
            } group flex items-center px-4 py-2 text-sm`}
        >
          {children}
        </Link>
      )}
    </Menu.Item>
  );
  useEffect(() => {
    const handleStorageChange = () => {
      const accessToken = localStorage.getItem('accessToken');
      setIsLoggedIn(!!accessToken);
    };

    handleStorageChange(); // Check the initial state

    window.addEventListener('storage', handleStorageChange); // Listen for storage changes

    return () => {
      window.removeEventListener('storage', handleStorageChange); // Clean up the event listener
    };
  }, []);
  const handleLogout = () => {
    setShowLogoutModal(true);
  };
  const isCustomer = user.groups[0] === 'Customer';
  const isStaff = user.groups[0] === 'Staff';

  const handleConfirmLogout = async () => {
    try {
      // Send a POST request to the server's logout endpoint
      await axios.post('http://localhost:8000/api/logout/');
      // Clear user's authentication state client-side
      localStorage.removeItem('accessToken');
      localStorage.clear();
      // Redirect to login page
      navigate('/');
      setShowLogoutModal(false); // Close the modal
    } catch (error) {
      console.error('Error during logout:', error);
    }
  };


  return (
  <>
    <nav className="bg-gray-600">
      <div className="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8">
        <div className="relative flex items-center justify-between h-16"> {/* Adjusted for vertical alignment */}
          <div className="absolute inset-y-0 left-0 flex items-center sm:hidden">
            <button
              type="button"
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
              aria-controls="mobile-menu"
              aria-expanded="false"
              onClick={() => setIsOpen(!isOpen)}
            >
              <span className="sr-only">Open main menu</span>
              {isOpen ? (
                <XIcon className="block h-6 w-6" />
              ) : (
                <MenuIcon className="block h-6 w-6" />
              )}
            </button>
          </div>
          <div className={`${isOpen ? 'block' : 'hidden'} sm:hidden`} id="mobile-menu">
            <div className="px-2 pt-2 pb-3 space-y-1 bg-gray-600">
              {/* Mobile Navigation links */}
              <Link to="/product-list" className="text-gray-300 hover:bg-gray-700 block px-3 py-2 rounded-md text-base font-medium">
                Products
              </Link>
              <Link to="/orders" className="text-gray-300 hover:bg-gray-700 block px-3 py-2 rounded-md text-base font-medium">
                Orders
              </Link>
              {isStaff && (
              <Link to="/inventory" className="text-gray-300 hover:bg-gray-700 block px-3 py-2 rounded-md text-base font-medium">
                Inventory
              </Link>)}

              <Link to="/customers" className="text-gray-300 hover:bg-gray-700 block px-3 py-2 rounded-md text-base font-medium">
                Customers
              </Link>
              <Link to="/reports" className="text-gray-300 hover:bg-gray-700 block px-3 py-2 rounded-md text-base font-medium">
                Reports
              </Link>
            </div>
          </div>
          <div className="flex">

            <div className="flex-shrink-0 flex items-center">
              <Link to="/home" className="inline-flex items-center px-4 py-2 text-lg font-medium text-gray-300 hover:bg-gray-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-opacity-75">
                <HomeIcon className="h-6 w-6 mr-2" />
                Home
              </Link>
            </div>
            <div className="hidden md:ml-6 md:flex md:space-x-8">
              {/* Icons added next to each link */}
              <Menu as="div" className="relative inline-block text-left">
                <div>
                  <Menu.Button className="inline-flex justify-center w-full px-4 py-2 text-lg font-medium text-gray-300 hover:bg-gray-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-opacity-75">
                    <ClipboardListIcon className="h-6 w-6 mr-2" /> Products
                    <ChevronDownIcon className="w-5 h-5 ml-2 -mr-1" aria-hidden="true" />
                  </Menu.Button>
                </div>
                <Transition
                  as={React.Fragment}
                  enter="transition ease-out duration-100"
                  enterFrom="transform opacity-0 scale-95"
                  enterTo="transform opacity-100 scale-100"
                  leave="transition ease-in duration-75"
                  leaveFrom="transform opacity-100 scale-100"
                  leaveTo="transform opacity-0 scale-95"
                >
                  <Menu.Items className="absolute right-0 w-56 mt-2 origin-top-right bg-white divide-y divide-gray-100 rounded-md shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                    <div className="px-1 py-1 ">
                      <DropdownLink to="/product-list">Product List</DropdownLink>
                      {isStaff && (<>
                      <DropdownLink to="/product-form">Product Form</DropdownLink>
                      </>)}
                    </div>
                  </Menu.Items>
                </Transition>
              </Menu>
              <Menu as="div" className="relative inline-block text-left">
                <div>
                  <Menu.Button className="inline-flex justify-center w-full px-4 py-2 text-lg font-medium text-gray-300 hover:bg-gray-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-opacity-75">
                    <ShoppingCartIcon className="h-6 w-6 mr-2" /> Orders
                    <ChevronDownIcon className="w-5 h-5 ml-2 -mr-1" aria-hidden="true" />
                  </Menu.Button>
                </div>
                <Transition
                  as={React.Fragment}
                  enter="transition ease-out duration-100"
                  enterFrom="transform opacity-0 scale-95"
                  enterTo="transform opacity-100 scale-100"
                  leave="transition ease-in duration-75"
                  leaveFrom="transform opacity-100 scale-100"
                  leaveTo="transform opacity-0 scale-95"
                >
                  <Menu.Items className="absolute right-0 w-56 mt-2 origin-top-right bg-white divide-y divide-gray-100 rounded-md shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                    <div className="px-1 py-1 ">
                    {isStaff && (<>
                      <DropdownLink to="/order-details">Order Details</DropdownLink>
                      {/*<DropdownLink to="/order-status">Order Status</DropdownLink>*/}
                      <DropdownLink to ="/pending-orders">Customer pending orders</DropdownLink>
                      <DropdownLink to ="/update-order-status">Update Specific Order </DropdownLink>
                      </>)}
                     {isCustomer && (<>
                      <DropdownLink to="/create-order">Create Order</DropdownLink>
                      <DropdownLink to="/customer-order-detail">My Order Details</DropdownLink>
                      <DropdownLink to="/customer-order-history">My Order History</DropdownLink>
                      </>)}

                    </div>
                  </Menu.Items>
                </Transition>
              </Menu>
                {isStaff && (
              <Menu as="div" className="relative inline-block text-left">
                <div>
                  <Menu.Button className="inline-flex justify-center w-full px-4 py-2 text-lg font-medium text-gray-300 hover:bg-gray-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-opacity-75">
                    <ArchiveIcon className="h-6 w-6 mr-2" /> Inventory
                    <ChevronDownIcon className="w-5 h-5 ml-2 -mr-1" aria-hidden="true" />
                  </Menu.Button>
                </div>
                <Transition
                  as={React.Fragment}
                  enter="transition ease-out duration-100"
                  enterFrom="transform opacity-0 scale-95"
                  enterTo="transform opacity-100 scale-100"
                  leave="transition ease-in duration-75"
                  leaveFrom="transform opacity-100 scale-100"
                  leaveTo="transform opacity-0 scale-95"
                >
                  <Menu.Items className="absolute right-0 w-56 mt-2 origin-top-right bg-white divide-y divide-gray-100 rounded-md shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                    <div className="px-1 py-1 ">

                      <DropdownLink to="/inventory-report">Inventory Report</DropdownLink>
                    </div>
                  </Menu.Items>
                </Transition>
              </Menu>
                )}

                {isStaff && (
              <Menu as="div" className="relative inline-block text-left">
                <div>
                  <Menu.Button className="inline-flex justify-center w-full px-4 py-2 text-lg font-medium text-gray-300 hover:bg-gray-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-opacity-75">
                    <UserGroupIcon className="h-6 w-6 mr-2" /> Customers
                    <ChevronDownIcon className="w-5 h-5 ml-2 -mr-1" aria-hidden="true" />
                  </Menu.Button>
                </div>
                <Transition
                  as={React.Fragment}
                  enter="transition ease-out duration-100"
                  enterFrom="transform opacity-0 scale-95"
                  enterTo="transform opacity-100 scale-100"
                  leave="transition ease-in duration-75"
                  leaveFrom="transform opacity-100 scale-100"
                  leaveTo="transform opacity-0 scale-95"
                >
                  <Menu.Items className="absolute right-0 w-56 mt-2 origin-top-right bg-white divide-y divide-gray-100 rounded-md shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                    <div className="px-1 py-1 ">
                      <DropdownLink to="/customer-list">Customer List</DropdownLink>
                    </div>
                  </Menu.Items>
                </Transition>
              </Menu>
                )}
               {/* {isStaff && (
              <Link to="/reports" className="flex items-center text-gray-300 hover:bg-gray-700 px-3 py-2 rounded-md transition duration-300">
                <ChartBarIcon className="h-5 w-5 mr-2" /> Reports

              </Link>)}*/}
            </div>
            <Menu as="div" className="relative inline-block text-left">
  <div>
    <Menu.Button className="inline-flex justify-center w-full px-4 py-2 text-lg font-medium text-gray-300 hover:bg-gray-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-opacity-75">
      <UserIcon className="h-6 w-6 mr-2" /> Account
      <ChevronDownIcon className="w-5 h-5 ml-2 mr-1 " aria-hidden="true" />
    </Menu.Button>
  </div>
  <Transition
    as={React.Fragment}
    enter="transition ease-out duration-100"
    enterFrom="transform opacity-0 scale-95"
    enterTo="transform opacity-100 scale-100"
    leave="transition ease-in duration-75"
    leaveFrom="transform opacity-100 scale-100"
    leaveTo="transform opacity-0 scale-95"
  >
    <Menu.Items className="absolute right-0 w-56 mt-2 origin-top-right bg-white divide-y divide-gray-100 rounded-md shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
      <div className="px-1 py-1">
        <DropdownLink to="/profile">View Profile</DropdownLink>
        <DropdownLink to ="/faq"> FAQ </DropdownLink>
        {isLoggedIn && (
          <Menu.Item>
            <button
              onClick={handleLogout}
              className="w-full text-left px-4 py-2 text-sm text-red-500 hover:bg-red-500 hover:text-white transition duration-300"
            >
              Log Out
            </button>
          </Menu.Item>
        )}
      </div>
    </Menu.Items>
  </Transition>
</Menu>

          <div className="flex items-center">
            <div className="ml-3 relative">
              {/* User profile dropdown or other components */}
            </div>
          </div>
        </div>
      </div>
        </div>
    </nav>
   <LogoutModal
        isOpen={showLogoutModal}
        onConfirm={handleConfirmLogout}
        onCancel={() => setShowLogoutModal(false)}
      />
      </>
  );
};

export default Navbar;
